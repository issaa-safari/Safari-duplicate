/* @ds-bundle: {"format":4,"namespace":"SafariAdventureRidersDesignSystem_473602","components":[{"name":"Avatar","sourcePath":"components/data-display/Avatar.jsx"},{"name":"StaffPill","sourcePath":"components/data-display/Avatar.jsx"},{"name":"Card","sourcePath":"components/data-display/Card.jsx"},{"name":"FeatureCard","sourcePath":"components/data-display/Card.jsx"},{"name":"ProgressBar","sourcePath":"components/data-display/ProgressBar.jsx"},{"name":"Tooltip","sourcePath":"components/data-display/Tooltip.jsx"},{"name":"Alert","sourcePath":"components/feedback/Alert.jsx"},{"name":"StatusBadge","sourcePath":"components/feedback/StatusBadge.jsx"},{"name":"TrailBadge","sourcePath":"components/feedback/StatusBadge.jsx"},{"name":"Eyebrow","sourcePath":"components/feedback/StatusBadge.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Button","sourcePath":"components/forms/Button.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Field","sourcePath":"components/forms/Field.jsx"},{"name":"TextareaField","sourcePath":"components/forms/Field.jsx"},{"name":"SelectField","sourcePath":"components/forms/Field.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Toggle","sourcePath":"components/forms/Toggle.jsx"},{"name":"LanguageToggle","sourcePath":"components/navigation/NavLink.jsx"},{"name":"NavLink","sourcePath":"components/navigation/NavLink.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"Dialog","sourcePath":"components/overlay/Dialog.jsx"}],"sourceHashes":{"components/data-display/Avatar.jsx":"fefada75716c","components/data-display/Card.jsx":"253a7724ffcd","components/data-display/ProgressBar.jsx":"11c378a946da","components/data-display/Tooltip.jsx":"88c4a9bb7a53","components/feedback/Alert.jsx":"3a9f3146a6b4","components/feedback/StatusBadge.jsx":"33b0c0ac630d","components/feedback/Toast.jsx":"c750f7e59fa4","components/forms/Button.jsx":"b6e2927410fd","components/forms/Checkbox.jsx":"4020da3c4bbf","components/forms/Field.jsx":"dfdcc1fc909c","components/forms/Radio.jsx":"a9ea17c6619d","components/forms/Toggle.jsx":"8b6d75762fae","components/navigation/NavLink.jsx":"e602486df2bd","components/navigation/Tabs.jsx":"eec9f97b592d","components/overlay/Dialog.jsx":"b86947f900ff","ui_kits/website/AdminPage.jsx":"a4d24406c6a4","ui_kits/website/App.jsx":"c014cca4b4a9","ui_kits/website/DashboardPage.jsx":"77b606fd657c","ui_kits/website/Footer.jsx":"5e0248f3a4f6","ui_kits/website/Header.jsx":"f8114446894e","ui_kits/website/HomePage.jsx":"a4bb8dc1711c","ui_kits/website/QuoteRequestPage.jsx":"a02e39c8cb9a","ui_kits/website/TourDetailPage.jsx":"6c4240ce4ebd","ui_kits/website/ToursPage.jsx":"d289ccb663e4"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.SafariAdventureRidersDesignSystem_473602 = window.SafariAdventureRidersDesignSystem_473602 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/data-display/Avatar.jsx
try { (() => {
function Avatar({
  name,
  size = 44,
  color = 'var(--olive)'
}) {
  const initial = (name || '?').trim()[0]?.toUpperCase() || '?';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: size,
      height: size,
      borderRadius: '50%',
      background: color,
      color: '#fff',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontWeight: 700,
      fontFamily: 'var(--font-display)',
      fontSize: size * 0.4,
      flexShrink: 0
    }
  }, initial);
}

// Staff pill — avatar + name + role, as seen in "Meet Your Team".
function StaffPill({
  name,
  role
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      background: '#fff',
      borderRadius: 'var(--radius-pill)',
      padding: '10px 20px 10px 10px',
      border: '1px solid var(--border-warm)'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: name,
    size: 44
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: 'var(--fs-body)',
      color: 'var(--text-heading)',
      fontFamily: 'var(--font-body)'
    }
  }, name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--fs-xs)',
      color: 'var(--text-body)',
      fontFamily: 'var(--font-body)'
    }
  }, role)));
}
Object.assign(__ds_scope, { Avatar, StaffPill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Card.jsx
try { (() => {
function Card({
  children,
  padding = 24,
  hoverable = false,
  style
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onMouseEnter: () => hoverable && setHover(true),
    onMouseLeave: () => hoverable && setHover(false),
    style: {
      background: '#fff',
      borderRadius: 'var(--radius-lg)',
      border: '1px solid var(--border-warm)',
      padding,
      transition: 'transform var(--dur-base) var(--ease-out-expo), box-shadow var(--dur-base) var(--ease-out-expo)',
      transform: hover ? 'translateY(var(--lift-row))' : 'none',
      boxShadow: hover ? 'var(--shadow-card)' : 'none',
      ...style
    }
  }, children);
}

// Feature card — full-bleed image, accent-tinted gradient, content pinned to bottom.
// Used for "Choose Your Trail" (bike vs private) style features.
function FeatureCard({
  imageUrl,
  accent,
  badge,
  heading,
  body,
  cta,
  href
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", {
    href: href,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'block',
      position: 'relative',
      borderRadius: 'var(--radius-xl)',
      overflow: 'hidden',
      minHeight: 360,
      textDecoration: 'none',
      transform: hover ? `translateY(var(--lift-card))` : 'none',
      transition: 'transform var(--dur-base) var(--ease-out-expo)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      backgroundImage: `url(${imageUrl})`,
      backgroundSize: 'cover',
      backgroundPosition: 'center'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: `linear-gradient(to top, ${accent}ee 0%, ${accent}44 40%, rgba(0,0,0,0.15) 100%)`
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 1,
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'flex-end',
      height: '100%',
      minHeight: 360,
      padding: '28px 26px',
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      background: 'rgba(255,255,255,0.15)',
      border: '1px solid rgba(255,255,255,0.3)',
      backdropFilter: 'blur(4px)',
      borderRadius: 'var(--radius-pill)',
      padding: '4px 14px',
      fontSize: 'var(--fs-xs)',
      fontWeight: 700,
      letterSpacing: 'var(--ls-eyebrow)',
      textTransform: 'uppercase',
      color: '#fff',
      fontFamily: 'var(--font-body)',
      marginBottom: 14,
      alignSelf: 'flex-start'
    }
  }, badge), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--fs-h3)',
      fontWeight: 700,
      color: '#fff',
      margin: '0 0 10px',
      lineHeight: 'var(--lh-heading)'
    }
  }, heading), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'rgba(255,255,255,0.88)',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--fs-body)',
      lineHeight: 'var(--lh-body)',
      margin: '0 0 22px'
    }
  }, body), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      background: '#fff',
      color: accent,
      fontWeight: 700,
      fontSize: 'var(--fs-sm)',
      padding: '10px 20px',
      borderRadius: 'var(--radius-md)',
      fontFamily: 'var(--font-body)'
    }
  }, cta, " ", /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true"
  }, "\u2192"))));
}
Object.assign(__ds_scope, { Card, FeatureCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Card.jsx", error: String((e && e.message) || e) }); }

// components/data-display/ProgressBar.jsx
try { (() => {
function ProgressBar({
  percent = 0,
  color
}) {
  const barColor = color || (percent >= 80 ? 'var(--murram)' : 'var(--olive)');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: 4,
      borderRadius: 'var(--radius-pill)',
      background: 'var(--sand)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      width: `${Math.min(100, Math.max(0, percent))}%`,
      background: barColor,
      borderRadius: 'var(--radius-pill)',
      transition: 'width var(--dur-slow) var(--ease-out-expo)'
    }
  }));
}
Object.assign(__ds_scope, { ProgressBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/ProgressBar.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Tooltip.jsx
try { (() => {
function Tooltip({
  label,
  children
}) {
  const [show, setShow] = React.useState(false);
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'inline-flex'
    },
    onMouseEnter: () => setShow(true),
    onMouseLeave: () => setShow(false)
  }, children, show && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      bottom: '125%',
      left: '50%',
      transform: 'translateX(-50%)',
      background: 'var(--bush)',
      color: '#fff',
      fontSize: 11,
      fontFamily: 'var(--font-body)',
      padding: '6px 10px',
      borderRadius: 'var(--radius-sm)',
      whiteSpace: 'nowrap',
      boxShadow: 'var(--shadow-sm)',
      zIndex: 10
    }
  }, label));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Alert.jsx
try { (() => {
const VARIANT = {
  error: {
    bg: 'var(--status-danger-bg)',
    fg: 'var(--status-danger-fg)'
  },
  success: {
    bg: 'var(--status-success-bg)',
    fg: 'var(--status-success-fg)'
  },
  warning: {
    bg: 'var(--status-warn-bg)',
    fg: 'var(--status-warn-fg)'
  },
  info: {
    bg: 'var(--olive-tint)',
    fg: 'var(--olive-dk)'
  }
};
function Alert({
  variant = 'info',
  children
}) {
  const v = VARIANT[variant] || VARIANT.info;
  return /*#__PURE__*/React.createElement("p", {
    role: variant === 'error' ? 'alert' : 'status',
    style: {
      fontSize: 'var(--fs-sm)',
      borderRadius: 'var(--radius-md)',
      padding: '12px 16px',
      margin: 0,
      background: v.bg,
      color: v.fg,
      fontFamily: 'var(--font-body)',
      lineHeight: 'var(--lh-snug)'
    }
  }, children);
}
Object.assign(__ds_scope, { Alert });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Alert.jsx", error: String((e && e.message) || e) }); }

// components/feedback/StatusBadge.jsx
try { (() => {
const STATUS = {
  guaranteed: {
    bg: 'var(--status-success-bg)',
    fg: 'var(--status-success-fg)'
  },
  available: {
    bg: 'var(--status-success-bg)',
    fg: 'var(--status-success-fg)'
  },
  low: {
    bg: 'var(--status-warn-bg)',
    fg: 'var(--status-warn-fg)'
  },
  full: {
    bg: 'var(--status-neutral-bg)',
    fg: 'var(--status-neutral-fg)'
  },
  cancelled: {
    bg: 'var(--status-danger-bg)',
    fg: 'var(--status-danger-fg)'
  }
};
function StatusBadge({
  status = 'available',
  children
}) {
  const s = STATUS[status] || STATUS.available;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      padding: '3px 12px',
      borderRadius: 'var(--radius-pill)',
      background: s.bg,
      color: s.fg,
      fontSize: 12,
      fontWeight: 600,
      fontFamily: 'var(--font-body)'
    }
  }, children);
}

// Trail badge — glassy pill over photography (Choose Your Trail cards).
function TrailBadge({
  children
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      background: 'rgba(255,255,255,0.15)',
      border: '1px solid rgba(255,255,255,0.3)',
      backdropFilter: 'blur(4px)',
      WebkitBackdropFilter: 'blur(4px)',
      borderRadius: 'var(--radius-pill)',
      padding: '4px 14px',
      fontSize: 'var(--fs-xs)',
      fontWeight: 700,
      letterSpacing: 'var(--ls-eyebrow)',
      textTransform: 'uppercase',
      color: '#fff',
      fontFamily: 'var(--font-body)'
    }
  }, children);
}

// Eyebrow label — uppercase, olive, used above headings.
function Eyebrow({
  children
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--fs-xs)',
      fontWeight: 700,
      letterSpacing: 'var(--ls-eyebrow)',
      textTransform: 'uppercase',
      color: 'var(--olive)',
      fontFamily: 'var(--font-body)'
    }
  }, children);
}
Object.assign(__ds_scope, { StatusBadge, TrailBadge, Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/StatusBadge.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function Toast({
  variant = 'success',
  children,
  onClose
}) {
  const v = variant === 'error' ? {
    bg: 'var(--bush)',
    accent: 'var(--status-danger-fg)'
  } : {
    bg: 'var(--bush)',
    accent: 'var(--olive)'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      background: v.bg,
      color: '#fff',
      borderRadius: 'var(--radius-lg)',
      padding: '14px 18px',
      boxShadow: 'var(--shadow-float)',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--fs-sm)',
      maxWidth: 360
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: '50%',
      background: v.accent,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, children), onClose && /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    "aria-label": "Dismiss",
    style: {
      background: 'none',
      border: 'none',
      color: 'rgba(255,255,255,0.6)',
      cursor: 'pointer',
      fontSize: 16,
      lineHeight: 1,
      padding: 0
    }
  }, "\xD7"));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/forms/Button.jsx
try { (() => {
const VARIANT = {
  primary: {
    background: 'var(--olive)',
    color: '#fff',
    border: '1px solid var(--olive)'
  },
  secondary: {
    background: '#fff',
    color: 'var(--text-heading)',
    border: '1px solid var(--border-warm)'
  },
  ghost: {
    background: 'transparent',
    color: 'var(--olive)',
    border: '1.5px solid var(--olive)'
  },
  danger: {
    background: 'transparent',
    color: 'var(--status-danger-fg)',
    border: 'none'
  }
};
const SIZE = {
  sm: {
    padding: '9px 16px',
    fontSize: 'var(--fs-sm)'
  },
  md: {
    padding: '12px 24px',
    fontSize: 'var(--fs-base)'
  },
  lg: {
    padding: '14px 28px',
    fontSize: 'var(--fs-base)'
  }
};
const HOVER_BG = {
  primary: 'var(--olive-dk)',
  secondary: 'var(--sand)',
  ghost: 'var(--olive-tint)',
  danger: 'transparent'
};
function Button({
  variant = 'primary',
  size = 'md',
  loading = false,
  loadingText,
  disabled = false,
  icon,
  iconPosition = 'left',
  children,
  onClick,
  type = 'button'
}) {
  const [hover, setHover] = React.useState(false);
  const v = VARIANT[variant] || VARIANT.primary;
  const s = SIZE[size] || SIZE.md;
  const isDisabled = disabled || loading;
  return /*#__PURE__*/React.createElement("button", {
    type: type,
    disabled: isDisabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      fontFamily: 'var(--font-body)',
      fontWeight: 700,
      borderRadius: 'var(--radius-md)',
      cursor: isDisabled ? 'not-allowed' : 'pointer',
      opacity: isDisabled ? 0.55 : 1,
      transition: 'var(--transition-colors), transform var(--dur-fast) var(--ease-out-expo)',
      transform: hover && !isDisabled ? 'translateY(-1px)' : 'none',
      ...v,
      ...s,
      background: hover && !isDisabled ? HOVER_BG[variant] : v.background
    }
  }, icon && iconPosition === 'left' && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex'
    }
  }, icon), loading ? loadingText || 'Saving…' : children, icon && iconPosition === 'right' && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex'
    }
  }, icon));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Button.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function Checkbox({
  checked,
  onChange,
  label,
  disabled = false
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1
    }
  }, /*#__PURE__*/React.createElement("span", {
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      width: 18,
      height: 18,
      borderRadius: 5,
      border: `1.5px solid ${checked ? 'var(--olive)' : 'var(--border-warm)'}`,
      background: checked ? 'var(--olive)' : '#fff',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'var(--transition-colors)',
      flexShrink: 0
    }
  }, checked && /*#__PURE__*/React.createElement("svg", {
    width: "11",
    height: "9",
    viewBox: "0 0 11 9",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M1 4.5L4 7.5L10 1",
    stroke: "white",
    strokeWidth: "1.8",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--fs-body)',
      color: 'var(--text-heading)',
      fontFamily: 'var(--font-body)'
    }
  }, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Field.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const fieldStyle = hasError => ({
  width: '100%',
  boxSizing: 'border-box',
  borderRadius: 'var(--radius-md)',
  border: `1px solid ${hasError ? 'var(--status-danger-fg)' : 'var(--border-warm)'}`,
  padding: '10px 14px',
  fontSize: 'var(--fs-body)',
  fontFamily: 'var(--font-body)',
  color: 'var(--text-heading)',
  background: '#fff',
  outline: 'none'
});
function Label({
  children,
  required
}) {
  if (!children) return null;
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'block',
      fontSize: 'var(--fs-sm)',
      fontWeight: 600,
      color: 'var(--text-heading)',
      marginBottom: 6,
      fontFamily: 'var(--font-body)'
    }
  }, children, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--murram)'
    }
  }, " *"));
}
function ErrorText({
  children
}) {
  if (!children) return null;
  return /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--fs-xs)',
      color: 'var(--status-danger-fg)',
      margin: '6px 0 0'
    }
  }, children);
}
function useFocusRing(hasError) {
  const [focused, setFocused] = React.useState(false);
  return {
    onFocus: () => setFocused(true),
    onBlur: () => setFocused(false),
    style: focused ? {
      boxShadow: `0 0 0 3px ${hasError ? 'rgba(176,73,43,0.18)' : 'rgba(122,154,74,0.25)'}`,
      borderColor: hasError ? 'var(--status-danger-fg)' : 'var(--olive)'
    } : {}
  };
}
function Field({
  label,
  error,
  required,
  ...props
}) {
  const ring = useFocusRing(!!error);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Label, {
    required: required
  }, label), /*#__PURE__*/React.createElement("input", _extends({}, props, ring, {
    style: {
      ...fieldStyle(!!error),
      ...ring.style
    }
  })), /*#__PURE__*/React.createElement(ErrorText, null, error));
}
function TextareaField({
  label,
  error,
  required,
  rows = 4,
  ...props
}) {
  const ring = useFocusRing(!!error);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Label, {
    required: required
  }, label), /*#__PURE__*/React.createElement("textarea", _extends({
    rows: rows
  }, props, ring, {
    style: {
      ...fieldStyle(!!error),
      ...ring.style,
      resize: 'vertical',
      fontFamily: 'var(--font-body)'
    }
  })), /*#__PURE__*/React.createElement(ErrorText, null, error));
}
function SelectField({
  label,
  error,
  required,
  children,
  ...props
}) {
  const ring = useFocusRing(!!error);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Label, {
    required: required
  }, label), /*#__PURE__*/React.createElement("select", _extends({}, props, ring, {
    style: {
      ...fieldStyle(!!error),
      ...ring.style,
      appearance: 'auto'
    }
  }), children), /*#__PURE__*/React.createElement(ErrorText, null, error));
}
Object.assign(__ds_scope, { Field, TextareaField, SelectField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Field.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function Radio({
  checked,
  onChange,
  label,
  name,
  disabled = false
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1
    }
  }, /*#__PURE__*/React.createElement("span", {
    onClick: () => !disabled && onChange && onChange(),
    role: "radio",
    "aria-checked": checked,
    style: {
      width: 18,
      height: 18,
      borderRadius: '50%',
      border: `1.5px solid ${checked ? 'var(--olive)' : 'var(--border-warm)'}`,
      background: '#fff',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'var(--transition-colors)',
      flexShrink: 0
    }
  }, checked && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 9,
      height: 9,
      borderRadius: '50%',
      background: 'var(--olive)'
    }
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--fs-body)',
      color: 'var(--text-heading)',
      fontFamily: 'var(--font-body)'
    }
  }, label));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Toggle.jsx
try { (() => {
function Toggle({
  checked,
  onChange,
  label,
  disabled = false
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 12,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    role: "switch",
    "aria-checked": checked,
    disabled: disabled,
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      position: 'relative',
      display: 'inline-flex',
      height: 22,
      width: 38,
      flexShrink: 0,
      borderRadius: 'var(--radius-pill)',
      border: '2px solid transparent',
      background: checked ? 'var(--olive)' : '#D6D2C6',
      transition: 'background var(--dur-fast) var(--ease-out-expo)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      padding: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      height: 16,
      width: 16,
      borderRadius: '50%',
      background: '#fff',
      boxShadow: 'var(--shadow-sm)',
      transform: checked ? 'translateX(16px)' : 'translateX(0)',
      transition: 'transform var(--dur-fast) var(--ease-out-expo)'
    }
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--fs-body)',
      color: 'var(--text-heading)',
      fontFamily: 'var(--font-body)'
    }
  }, label));
}
Object.assign(__ds_scope, { Toggle });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Toggle.jsx", error: String((e && e.message) || e) }); }

// components/navigation/NavLink.jsx
try { (() => {
function LanguageToggle({
  value = 'en',
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      paddingInlineStart: 16,
      borderInlineStart: '1px solid var(--border-warm)'
    }
  }, ['en', 'ar'].map(lang => /*#__PURE__*/React.createElement("button", {
    key: lang,
    onClick: () => onChange && onChange(lang),
    style: {
      fontSize: 12,
      fontFamily: 'var(--font-body)',
      padding: '6px 12px',
      borderRadius: 'var(--radius-sm)',
      border: 'none',
      cursor: 'pointer',
      fontWeight: value === lang ? 700 : 500,
      background: value === lang ? '#E5E7EB' : 'transparent',
      color: value === lang ? 'var(--text-heading)' : 'var(--text-muted)',
      transition: 'var(--transition-colors)'
    }
  }, lang === 'en' ? 'EN' : 'العربية')));
}
function NavLink({
  children,
  active = false,
  onClick
}) {
  return /*#__PURE__*/React.createElement("a", {
    onClick: onClick,
    style: {
      fontSize: 'var(--fs-sm)',
      fontWeight: 500,
      color: active ? 'var(--text-heading)' : 'var(--text-body)',
      textDecoration: 'none',
      cursor: 'pointer',
      fontFamily: 'var(--font-body)'
    }
  }, children);
}
Object.assign(__ds_scope, { LanguageToggle, NavLink });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/NavLink.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function Tabs({
  tabs,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 4,
      borderBottom: '1px solid var(--border-warm)'
    }
  }, tabs.map(tab => {
    const active = tab === value;
    return /*#__PURE__*/React.createElement("button", {
      key: tab,
      onClick: () => onChange && onChange(tab),
      style: {
        padding: '10px 18px',
        fontSize: 'var(--fs-body)',
        fontFamily: 'var(--font-body)',
        fontWeight: active ? 700 : 500,
        color: active ? 'var(--olive-dk)' : 'var(--text-body)',
        background: 'none',
        border: 'none',
        borderBottom: active ? '2px solid var(--olive)' : '2px solid transparent',
        marginBottom: -1,
        cursor: 'pointer',
        transition: 'var(--transition-colors)'
      }
    }, tab);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/overlay/Dialog.jsx
try { (() => {
function Dialog({
  title,
  children,
  onClose,
  footer
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 60,
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'center',
      paddingTop: '10vh',
      background: 'rgba(26,46,19,0.55)'
    },
    onClick: e => {
      if (e.target === e.currentTarget && onClose) onClose();
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      maxWidth: 420,
      background: '#fff',
      borderRadius: 'var(--radius-xl)',
      overflow: 'hidden',
      boxShadow: 'var(--shadow-float)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '14px 20px',
      borderBottom: '1px solid var(--border-warm)'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 15,
      fontWeight: 700,
      color: 'var(--text-heading)',
      margin: 0
    }
  }, title), /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    "aria-label": "Close",
    style: {
      background: 'none',
      border: 'none',
      fontSize: 20,
      lineHeight: 1,
      color: 'var(--text-muted)',
      cursor: 'pointer'
    }
  }, "\xD7")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 20,
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: 10,
      padding: '14px 20px',
      borderTop: '1px solid var(--border-warm)',
      background: 'var(--admin-bg)'
    }
  }, footer)));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlay/Dialog.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/AdminPage.jsx
try { (() => {
const {
  StatusBadge,
  Button,
  Toggle,
  Dialog,
  Field,
  TextareaField
} = window.SafariAdventureRidersDesignSystem_473602;
const ROWS = [{
  id: 1,
  tour: 'Nairobi to Coast Ride',
  dates: 'Aug 12–20',
  seats: '8/12',
  status: 'guaranteed'
}, {
  id: 2,
  tour: 'Masai Mara Private Safari',
  dates: 'Sep 3–11',
  seats: '10/12',
  status: 'low'
}, {
  id: 3,
  tour: 'Serengeti & Ngorongoro',
  dates: 'Oct 1–9',
  seats: '12/12',
  status: 'full'
}, {
  id: 4,
  tour: 'Mount Kenya Highlands Loop',
  dates: 'Nov 5–12',
  seats: '0/10',
  status: 'cancelled'
}];
function AdminPage() {
  const [showDialog, setShowDialog] = React.useState(false);
  const [visible, setVisible] = React.useState(true);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--admin-bg)',
      minHeight: '70vh',
      padding: '32px 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-md)',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 20,
      fontWeight: 700,
      color: 'var(--admin-text)',
      margin: 0
    }
  }, "Departures"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      color: 'var(--admin-text-muted)',
      margin: '4px 0 0'
    }
  }, "Admin \u2014 internal operations view")), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    onClick: () => setShowDialog(true)
  }, "+ New Departure")), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--admin-surface)',
      borderRadius: 12,
      border: '1px solid var(--admin-border)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '2fr 1fr 1fr 1fr auto',
      gap: 12,
      padding: '10px 20px',
      fontSize: 11,
      fontWeight: 700,
      color: 'var(--admin-text-muted)',
      textTransform: 'uppercase',
      letterSpacing: '0.04em',
      borderBottom: '1px solid var(--admin-border)'
    }
  }, /*#__PURE__*/React.createElement("span", null, "Tour"), /*#__PURE__*/React.createElement("span", null, "Dates"), /*#__PURE__*/React.createElement("span", null, "Seats"), /*#__PURE__*/React.createElement("span", null, "Status"), /*#__PURE__*/React.createElement("span", null)), ROWS.map(r => /*#__PURE__*/React.createElement("div", {
    key: r.id,
    style: {
      display: 'grid',
      gridTemplateColumns: '2fr 1fr 1fr 1fr auto',
      gap: 12,
      alignItems: 'center',
      padding: '14px 20px',
      borderBottom: '1px solid var(--admin-border)',
      fontSize: 13.5,
      fontFamily: 'var(--font-body)',
      color: 'var(--admin-text)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600
    }
  }, r.tour), /*#__PURE__*/React.createElement("span", null, r.dates), /*#__PURE__*/React.createElement("span", null, r.seats), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(StatusBadge, {
    status: r.status
  }, r.status === 'guaranteed' ? 'Guaranteed' : r.status === 'low' ? 'Low seats' : r.status === 'full' ? 'Full' : 'Cancelled')), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm"
  }, "Edit")))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 28,
      background: 'var(--admin-surface)',
      borderRadius: 12,
      border: '1px solid var(--admin-border)',
      padding: 20
    }
  }, /*#__PURE__*/React.createElement(Toggle, {
    checked: visible,
    onChange: setVisible,
    label: "Show departures publicly while seats remain"
  }))), showDialog && /*#__PURE__*/React.createElement(Dialog, {
    title: "Create Destination",
    onClose: () => setShowDialog(false),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      onClick: () => setShowDialog(false)
    }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      onClick: () => setShowDialog(false)
    }, "Create"))
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Name",
    required: true,
    placeholder: "Amboseli National Park"
  }), /*#__PURE__*/React.createElement(TextareaField, {
    label: "Description (English)",
    rows: 3
  })));
}
window.AdminPage = AdminPage;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/AdminPage.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/App.jsx
try { (() => {
function InfoPage({
  label
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '50vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 48,
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 22,
      fontWeight: 700,
      color: 'var(--text-heading)',
      margin: '0 0 8px'
    }
  }, label), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      color: 'var(--text-muted)',
      maxWidth: 380,
      margin: '0 auto'
    }
  }, "Not recreated in this snapshot \u2014 the real page exists in the codebase but wasn't a core screen for this kit.")));
}
function App() {
  const [route, setRoute] = React.useState('home');
  const [tour, setTour] = React.useState(null);
  const [lang, setLang] = React.useState('en');
  const [signedIn, setSignedIn] = React.useState(true);
  function go(next, payload) {
    setRoute(next);
    if (payload) setTour(payload);
    window.scrollTo(0, 0);
  }
  let page;
  if (route === 'home') page = /*#__PURE__*/React.createElement(window.HomePage, {
    lang: lang,
    go: go
  });else if (route === 'tours') page = /*#__PURE__*/React.createElement(window.ToursPage, {
    lang: lang,
    go: go
  });else if (route === 'tour-detail') page = /*#__PURE__*/React.createElement(window.TourDetailPage, {
    lang: lang,
    go: go,
    tour: tour
  });else if (route === 'quote') page = /*#__PURE__*/React.createElement(window.QuoteRequestPage, {
    lang: lang
  });else if (route === 'dashboard') page = /*#__PURE__*/React.createElement(window.DashboardPage, {
    lang: lang
  });else if (route === 'admin') page = /*#__PURE__*/React.createElement(window.AdminPage, null);else if (route === 'login') page = /*#__PURE__*/React.createElement(InfoPage, {
    label: "Sign In"
  });else page = /*#__PURE__*/React.createElement(InfoPage, {
    label: route.charAt(0).toUpperCase() + route.slice(1)
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)'
    }
  }, /*#__PURE__*/React.createElement(window.Header, {
    route: route,
    go: go,
    lang: lang,
    setLang: setLang,
    signedIn: signedIn
  }), page, /*#__PURE__*/React.createElement(window.Footer, {
    lang: lang,
    go: go
  }), /*#__PURE__*/React.createElement(window.WhatsAppFab, null), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      bottom: 24,
      left: 24,
      zIndex: 60,
      background: 'var(--bush)',
      borderRadius: 999,
      padding: '6px 6px',
      display: 'flex',
      gap: 4,
      boxShadow: 'var(--shadow-float)'
    }
  }, ['home', 'tours', 'quote', 'dashboard', 'admin'].map(r => /*#__PURE__*/React.createElement("button", {
    key: r,
    onClick: () => go(r),
    style: {
      border: 'none',
      borderRadius: 999,
      padding: '7px 14px',
      fontSize: 12,
      fontFamily: 'var(--font-body)',
      fontWeight: 600,
      cursor: 'pointer',
      textTransform: 'capitalize',
      background: route === r ? 'var(--olive)' : 'transparent',
      color: '#fff'
    }
  }, r))));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/DashboardPage.jsx
try { (() => {
const {
  Card,
  Button
} = window.SafariAdventureRidersDesignSystem_473602;
function DashboardPage({
  lang
}) {
  const isAr = lang === 'ar';
  return /*#__PURE__*/React.createElement("div", {
    dir: isAr ? 'rtl' : 'ltr',
    style: {
      background: 'var(--admin-bg)',
      minHeight: '70vh',
      padding: '48px 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-md)',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 24,
      fontWeight: 700,
      color: 'var(--text-heading)',
      margin: '0 0 4px'
    }
  }, "Welcome back, Sarah"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      color: 'var(--text-muted)',
      margin: '0 0 32px'
    }
  }, "Your bookings and trip documents in one place."), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 15,
      fontWeight: 700,
      color: 'var(--text-heading)',
      marginBottom: 14
    }
  }, "Upcoming trip"), /*#__PURE__*/React.createElement(Card, {
    style: {
      marginBottom: 32
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'space-between',
      gap: 16,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 18,
      fontWeight: 700,
      color: 'var(--text-heading)'
    }
  }, "Masai Mara Private Safari"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)',
      marginTop: 4
    }
  }, "Sep 3 \u2013 Sep 11, 2026 \xB7 2 travellers")), /*#__PURE__*/React.createElement("span", {
    style: {
      padding: '4px 12px',
      borderRadius: 999,
      background: 'var(--status-success-bg)',
      color: 'var(--status-success-fg)',
      fontSize: 12,
      fontWeight: 600
    }
  }, "Confirmed"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm"
  }, "View Booking"))), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 15,
      fontWeight: 700,
      color: 'var(--text-heading)',
      marginBottom: 14
    }
  }, "Past trips"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(240px,1fr))',
      gap: 16
    }
  }, [{
    t: 'Nairobi to Coast Ride',
    d: 'Mar 2025'
  }, {
    t: 'Amboseli & Kilimanjaro Views',
    d: 'Nov 2024'
  }].map(b => /*#__PURE__*/React.createElement(Card, {
    key: b.t
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      color: 'var(--text-heading)',
      fontFamily: 'var(--font-body)',
      marginBottom: 4
    }
  }, b.t), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, b.d))))));
}
window.DashboardPage = DashboardPage;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/DashboardPage.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Footer.jsx
try { (() => {
const {
  site,
  WHATSAPP_LINK
} = window;
function Footer({
  lang,
  go
}) {
  const isAr = lang === 'ar';
  const t = isAr ? {
    tagline: 'اختبر البرية. رحلات سفاري بقيادة خبراء عبر أكثر وجهات شرق أفريقيا شهرة.',
    explore: 'استكشف',
    browseTours: 'تصفح الجولات',
    gallery: 'معرض الصور',
    getQuote: 'احصل على عرض سعر',
    ourStory: 'قصتنا',
    company: 'الشركة',
    contactUs: 'اتصل بنا',
    privacy: 'سياسة الخصوصية',
    terms: 'شروط الخدمة',
    getInTouch: 'تواصل معنا',
    email: 'البريد الإلكتروني',
    phone: 'الهاتف',
    whatsapp: 'واتساب',
    rights: 'جميع الحقوق محفوظة.'
  } : {
    tagline: "Experience the wild. Expert-led safaris across East Africa's most iconic destinations.",
    explore: 'Explore',
    browseTours: 'Browse Tours',
    gallery: 'Gallery',
    getQuote: 'Get a Quote',
    ourStory: 'Our Story',
    company: 'Company',
    contactUs: 'Contact Us',
    privacy: 'Privacy Policy',
    terms: 'Terms of Service',
    getInTouch: 'Get in Touch',
    email: 'Email',
    phone: 'Phone',
    whatsapp: 'WhatsApp',
    rights: 'All rights reserved.'
  };
  const linkStyle = {
    color: 'rgba(255,255,255,0.65)',
    textDecoration: 'none',
    fontSize: 14,
    cursor: 'pointer',
    fontFamily: 'var(--font-body)'
  };
  return /*#__PURE__*/React.createElement("footer", {
    dir: isAr ? 'rtl' : 'ltr',
    style: {
      background: '#111827',
      color: '#d1d5db',
      marginTop: 60
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-lg)',
      margin: '0 auto',
      padding: '48px 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(200px,1fr))',
      gap: 32,
      marginBottom: 32
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-safari-riders.png",
    style: {
      height: 26
    },
    alt: ""
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700,
      color: '#fff',
      fontFamily: 'var(--font-display)'
    }
  }, "Safari Adventure Riders")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      color: '#9ca3af',
      fontFamily: 'var(--font-body)'
    }
  }, t.tagline)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontWeight: 700,
      color: '#fff',
      marginBottom: 16,
      fontFamily: 'var(--font-body)',
      fontSize: 15
    }
  }, t.explore), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("a", {
    style: linkStyle,
    onClick: () => go('tours')
  }, t.browseTours), /*#__PURE__*/React.createElement("a", {
    style: linkStyle,
    onClick: () => go('gallery')
  }, t.gallery), /*#__PURE__*/React.createElement("a", {
    style: linkStyle,
    onClick: () => go('quote')
  }, t.getQuote), /*#__PURE__*/React.createElement("a", {
    style: linkStyle,
    onClick: () => go('about')
  }, t.ourStory))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontWeight: 700,
      color: '#fff',
      marginBottom: 16,
      fontFamily: 'var(--font-body)',
      fontSize: 15
    }
  }, t.company), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("a", {
    style: linkStyle,
    onClick: () => go('contact')
  }, t.contactUs), /*#__PURE__*/React.createElement("a", {
    style: linkStyle
  }, t.privacy), /*#__PURE__*/React.createElement("a", {
    style: linkStyle
  }, t.terms))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontWeight: 700,
      color: '#fff',
      marginBottom: 16,
      fontFamily: 'var(--font-body)',
      fontSize: 15
    }
  }, t.getInTouch), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      fontSize: 14,
      fontFamily: 'var(--font-body)'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0
    }
  }, t.email, ": info@safariadventureriders.com"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0
    }
  }, t.phone, ": +254 710 789 789"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0
    }
  }, t.whatsapp, ": +254 710 789 789")))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid #1f2937',
      paddingTop: 24,
      textAlign: 'center',
      fontSize: 13,
      color: '#9ca3af',
      fontFamily: 'var(--font-body)'
    }
  }, "\xA9 2026 Safari Adventure Riders. ", t.rights)));
}
function WhatsAppFab() {
  return /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => e.preventDefault(),
    "aria-label": "Chat on WhatsApp",
    style: {
      position: 'fixed',
      bottom: 24,
      right: 24,
      zIndex: 50,
      width: 56,
      height: 56,
      borderRadius: '50%',
      background: 'var(--whatsapp)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: 'var(--shadow-float)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 32 32",
    style: {
      width: 28,
      height: 28,
      fill: '#fff'
    },
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M16.003 3.2c-7.06 0-12.8 5.74-12.8 12.8 0 2.26.6 4.46 1.74 6.4L3.2 28.8l6.57-1.72a12.74 12.74 0 0 0 6.23 1.6h.01c7.06 0 12.8-5.74 12.8-12.8 0-3.42-1.33-6.63-3.75-9.05A12.7 12.7 0 0 0 16.003 3.2Zm0 23.07h-.01a10.6 10.6 0 0 1-5.4-1.48l-.39-.23-4.03 1.06 1.08-3.93-.25-.4a10.55 10.55 0 0 1-1.62-5.63c0-5.86 4.77-10.62 10.63-10.62 2.84 0 5.5 1.1 7.51 3.11a10.55 10.55 0 0 1 3.11 7.52c0 5.86-4.77 10.63-10.63 10.63Zm5.83-7.96c-.32-.16-1.89-.93-2.18-1.04-.29-.11-.5-.16-.71.16-.21.32-.82 1.04-1 1.25-.18.21-.37.24-.69.08-.32-.16-1.35-.5-2.57-1.59-.95-.85-1.59-1.9-1.78-2.22-.18-.32-.02-.49.14-.65.14-.14.32-.37.48-.55.16-.18.21-.32.32-.53.11-.21.05-.4-.03-.56-.08-.16-.71-1.71-.97-2.34-.26-.62-.52-.53-.71-.54l-.6-.01c-.21 0-.55.08-.83.4-.29.32-1.09 1.07-1.09 2.61 0 1.54 1.12 3.03 1.28 3.24.16.21 2.2 3.36 5.33 4.71.74.32 1.32.51 1.78.65.75.24 1.43.21 1.97.13.6-.09 1.89-.77 2.16-1.52.27-.74.27-1.38.18-1.52-.08-.13-.29-.21-.61-.37Z"
  })));
}
window.Footer = Footer;
window.WhatsAppFab = WhatsAppFab;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Footer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Header.jsx
try { (() => {
const {
  LanguageToggle,
  Button
} = window.SafariAdventureRidersDesignSystem_473602;
function Header({
  route,
  go,
  lang,
  setLang,
  signedIn
}) {
  const isAr = lang === 'ar';
  const t = isAr ? {
    tours: 'الجولات',
    departures: 'الرحلات',
    gallery: 'المعرض',
    about: 'نبذة عنا',
    contact: 'اتصل بنا',
    dashboard: 'حسابي',
    signin: 'تسجيل الدخول',
    quote: 'طلب عرض سعر'
  } : {
    tours: 'Tours',
    departures: 'Departures',
    gallery: 'Gallery',
    about: 'About',
    contact: 'Contact',
    dashboard: 'Dashboard',
    signin: 'Sign In',
    quote: 'Request Quote'
  };
  const navItem = (key, label) => /*#__PURE__*/React.createElement("a", {
    key: key,
    onClick: () => go(key),
    style: {
      fontSize: 14,
      fontWeight: 500,
      cursor: 'pointer',
      fontFamily: 'var(--font-body)',
      color: route === key ? 'var(--text-heading)' : 'var(--text-body)'
    }
  }, label);
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 50,
      background: '#fff',
      borderBottom: '1px solid var(--border-warm)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-lg)',
      margin: '0 auto',
      padding: '14px 24px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("a", {
    onClick: () => go('home'),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      cursor: 'pointer',
      textDecoration: 'none'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-safari-riders.png",
    alt: "Safari Adventure Riders",
    style: {
      height: 34,
      width: 'auto'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700,
      color: 'var(--text-heading)',
      fontFamily: 'var(--font-display)',
      fontSize: 15
    }
  }, "Safari Adventure Riders")), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 22
    }
  }, navItem('tours', t.tours), navItem('departures', t.departures), navItem('gallery', t.gallery), navItem('about', t.about), navItem('contact', t.contact), signedIn ? navItem('dashboard', t.dashboard) : navItem('login', t.signin), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    onClick: () => go('quote')
  }, t.quote), /*#__PURE__*/React.createElement(LanguageToggle, {
    value: lang,
    onChange: setLang
  }))));
}
window.Header = Header;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Header.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/HomePage.jsx
try { (() => {
const {
  FeatureCard,
  Card,
  Eyebrow,
  Button
} = window.SafariAdventureRidersDesignSystem_473602;
const BIKE_IMG = 'https://images.unsplash.com/photo-1549366021-9f761d450615?auto=format&fit=crop&w=900&q=70';
const SAFARI_IMG = 'https://images.unsplash.com/photo-1534177616072-ef7dc120449d?auto=format&fit=crop&w=900&q=70';
const HERO_IMG = 'https://images.unsplash.com/photo-1516426122078-c23e76319801?auto=format&fit=crop&w=2000&q=70';
function HomePage({
  lang,
  go
}) {
  const isAr = lang === 'ar';
  const dir = isAr ? 'rtl' : 'ltr';
  const t = isAr ? {
    headline: 'اركب البرية. اقتحم البرية.',
    sub: 'جولات دراجات جماعية وسفاري خاصة في كينيا وشرق أفريقيا — مُصممة لمن يطلب أكثر من مجرد رحلة سياحية.',
    cta: 'اختر مسارك',
    quote: 'طلب عرض سعر',
    trailHeading: 'اختر مسارك',
    trailSub: 'مسارين مختلفان. نفس الشغف بأفريقيا.',
    c1: 'مقرنا نيروبي، كينيا',
    c2: 'تأسسنا عام 2009',
    c3: 'نتحدث الإنجليزية والعربية والسواحيلية',
    whyHeading: 'لماذا تحجز مباشرة؟',
    whySub: "ليس مجرد شعار — هذا ما يعنيه الحجز المباشر معنا عملياً.",
    testHeading: 'ماذا يقول مسافرونا',
    ctaHeading: 'هل أنت مستعد لتخطيط رحلتك؟',
    ctaSub: 'تواصل معنا لتحصل على عرض مخصص، أو ابدأ محادثة على واتساب.',
    ctaQuote: 'طلب عرض سعر',
    ctaWhatsapp: 'تحدث معنا على واتساب'
  } : {
    headline: 'Ride the Bush. Drive the Wild.',
    sub: 'Group bike tours and private safaris across Kenya and East Africa — designed for people who want more than a package holiday.',
    cta: 'Plan Your Adventure',
    quote: 'Request a Quote',
    trailHeading: 'Choose Your Trail',
    trailSub: 'Two different paths. The same passion for East Africa.',
    c1: 'Based in Nairobi, Kenya',
    c2: 'Operating since 2009',
    c3: 'English · Arabic · Swahili',
    whyHeading: 'Why book direct?',
    whySub: "Not a slogan — here's what booking direct with us actually means.",
    testHeading: 'What Our Travellers Say',
    ctaHeading: 'Ready to plan your trip?',
    ctaSub: 'Get in touch for a personalised quote, or start a conversation on WhatsApp.',
    ctaQuote: 'Request a Quote',
    ctaWhatsapp: 'Chat on WhatsApp'
  };
  const whyPoints = isAr ? [{
    title: 'بدون رسوم وكالات',
    body: 'أنت تتفاوض مباشرة مع المشغل الذي ينفذ الرحلة. لا وسيط، لا هامش ربح مضخوم.'
  }, {
    title: 'مرشدون صمموا المسارات بأنفسهم',
    body: 'صمم مرشدونا مسارات الرحلات من خلال سنوات في الميدان — وليس من كتالوج.'
  }, {
    title: 'دعم عبر واتساب بشكل أساسي',
    body: 'بالعربية والإنجليزية والسواحيلية. أشخاص حقيقيون لا صندوق تذاكر.'
  }] : [{
    title: 'No agency markup',
    body: "You're quoting directly with the operator who runs the trip. No middleman, no inflated margins."
  }, {
    title: 'Guides who built the routes',
    body: 'Our guides designed the itineraries from years in the field — not adapted from a catalogue.'
  }, {
    title: 'WhatsApp-first support',
    body: 'English, Arabic and Swahili. Real people, not a ticket queue.'
  }];
  const reviews = [{
    name: 'Sarah M.',
    loc: 'London, UK',
    text: 'The most incredible trip of our lives. Our guide spotted the Big Five within two days.'
  }, {
    name: 'Abdullah A.',
    loc: 'Riyadh, Saudi Arabia',
    text: 'Everything was arranged perfectly from the airport pickup to the final game drive.'
  }, {
    name: 'Elena & Marco',
    loc: 'Milan, Italy',
    text: 'Witnessing the Great Migration was a dream come true. We will be back.'
  }];
  return /*#__PURE__*/React.createElement("div", {
    dir: dir
  }, /*#__PURE__*/React.createElement("section", {
    style: {
      position: 'relative',
      minHeight: '86vh',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'flex-end',
      overflow: 'hidden',
      background: 'var(--bush)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      backgroundImage: `url(${HERO_IMG})`,
      backgroundSize: 'cover',
      backgroundPosition: 'center'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'var(--grad-hero)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 1,
      maxWidth: 'var(--container-sm)',
      margin: '0 auto',
      width: '100%',
      padding: '0 24px 72px'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--fs-hero)',
      fontWeight: 700,
      color: '#fff',
      lineHeight: 'var(--lh-tight)',
      margin: '0 0 20px',
      letterSpacing: 'var(--ls-tight)'
    }
  }, t.headline), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-on-dark)',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--fs-lg)',
      lineHeight: 'var(--lh-relaxed)',
      margin: '0 0 36px',
      maxWidth: 560
    }
  }, t.sub), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("a", {
    onClick: () => go('tours'),
    style: {
      background: '#fff',
      color: 'var(--bush)',
      fontFamily: 'var(--font-body)',
      fontWeight: 700,
      fontSize: 16,
      padding: '14px 32px',
      borderRadius: 8,
      cursor: 'pointer'
    }
  }, t.cta), /*#__PURE__*/React.createElement("a", {
    onClick: () => go('quote'),
    style: {
      border: '2px solid rgba(255,255,255,0.5)',
      color: '#fff',
      fontFamily: 'var(--font-body)',
      fontWeight: 600,
      fontSize: 16,
      padding: '12px 28px',
      borderRadius: 8,
      cursor: 'pointer'
    }
  }, t.quote)))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--bush)',
      padding: 'var(--section-pad-y) var(--section-pad-x)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-md)',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      marginBottom: 40
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--fs-display)',
      fontWeight: 700,
      color: '#fff',
      margin: '0 0 10px'
    }
  }, t.trailHeading), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-on-dark-soft)',
      fontFamily: 'var(--font-body)',
      margin: 0
    }
  }, t.trailSub)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(300px,1fr))',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement(FeatureCard, {
    imageUrl: BIKE_IMG,
    accent: "#B0492B",
    badge: isAr ? 'جولات الدراجات' : 'Group Bike Tours',
    heading: isAr ? 'اركب البرية' : 'Ride the Bush',
    body: isAr ? 'جولات دراجات جماعية بقيادة خبراء من نيروبي إلى الساحل.' : 'Expert-led group rides from Nairobi to the coast. Fully supported, KTM-grade adventure.',
    cta: isAr ? 'استكشف جولات الدراجات' : 'Explore Bike Tours',
    href: "#"
  }), /*#__PURE__*/React.createElement(FeatureCard, {
    imageUrl: SAFARI_IMG,
    accent: "#C9A24B",
    badge: isAr ? 'سفاري خاص' : 'Private Safari',
    heading: isAr ? 'أطلق العنان للبرية' : 'Drive the Wild',
    body: isAr ? 'مسارات مخصصة، مخيمات حصرية، مجموعتك وحدها فقط.' : 'Custom itineraries, exclusive camps, your group only.',
    cta: isAr ? 'استكشف السفاري الخاص' : 'Explore Private Safaris',
    href: "#"
  })))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--bush)',
      padding: 'var(--section-pad-y-sm) var(--section-pad-x)',
      borderTop: '1px solid rgba(255,255,255,0.08)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 900,
      margin: '0 auto',
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'center',
      gap: '8px 40px'
    }
  }, [t.c1, t.c2, t.c3].map((f, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      color: 'var(--text-on-dark-soft)',
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      letterSpacing: 'var(--ls-wide)'
    }
  }, i > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'rgba(234,227,210,0.3)',
      marginInlineEnd: 10
    }
  }, "\xB7"), f)))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--sand)',
      padding: 'var(--section-pad-y) var(--section-pad-x)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-md)',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--fs-h2)',
      fontWeight: 700,
      color: 'var(--bush)',
      margin: '0 0 10px'
    }
  }, t.whyHeading), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--stone)',
      fontFamily: 'var(--font-body)',
      margin: 0
    }
  }, t.whySub)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(260px,1fr))',
      gap: 24
    }
  }, whyPoints.map(p => /*#__PURE__*/React.createElement(Card, {
    key: p.title
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 16,
      fontWeight: 700,
      color: 'var(--bush)',
      margin: '0 0 10px'
    }
  }, p.title), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--stone)',
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      lineHeight: 1.65,
      margin: 0
    }
  }, p.body)))))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: '#fff',
      padding: '64px 24px 80px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-md)',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--fs-h2)',
      fontWeight: 700,
      color: 'var(--bush)',
      margin: '0 0 32px'
    }
  }, t.testHeading), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(260px,1fr))',
      gap: 24
    }
  }, reviews.map(r => /*#__PURE__*/React.createElement(Card, {
    key: r.name
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--star)',
      fontSize: 16,
      marginBottom: 12
    }
  }, "\u2605\u2605\u2605\u2605\u2605"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-heading)',
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      lineHeight: 1.7,
      margin: '0 0 20px'
    }
  }, "\u201C", r.text, "\u201D"), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--border-warm)',
      paddingTop: 14
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontWeight: 600,
      color: 'var(--text-heading)',
      fontFamily: 'var(--font-body)'
    }
  }, r.name), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 13,
      color: 'var(--olive)',
      fontFamily: 'var(--font-body)'
    }
  }, r.loc))))))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--bush)',
      padding: '80px 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 640,
      margin: '0 auto',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--fs-display)',
      fontWeight: 700,
      color: '#fff',
      margin: '0 0 16px'
    }
  }, t.ctaHeading), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-on-dark-soft)',
      fontFamily: 'var(--font-body)',
      fontSize: 16,
      lineHeight: 1.7,
      margin: '0 0 36px'
    }
  }, t.ctaSub), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 14,
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    onClick: () => go('quote')
  }, t.ctaQuote), /*#__PURE__*/React.createElement("a", {
    onClick: e => e.preventDefault(),
    style: {
      background: 'var(--whatsapp)',
      color: '#fff',
      fontFamily: 'var(--font-body)',
      fontWeight: 700,
      fontSize: 16,
      padding: '14px 28px',
      borderRadius: 8,
      cursor: 'pointer'
    }
  }, t.ctaWhatsapp)))));
}
window.HomePage = HomePage;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/HomePage.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/QuoteRequestPage.jsx
try { (() => {
const {
  Field,
  TextareaField,
  SelectField,
  Checkbox,
  Radio,
  Button,
  Alert
} = window.SafariAdventureRidersDesignSystem_473602;
function QuoteRequestPage({
  lang
}) {
  const isAr = lang === 'ar';
  const [trail, setTrail] = React.useState('bike');
  const [agree, setAgree] = React.useState(false);
  const [sent, setSent] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    dir: isAr ? 'rtl' : 'ltr',
    style: {
      background: 'var(--sand)',
      minHeight: '70vh',
      padding: '64px 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 640,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--fs-h2)',
      fontWeight: 700,
      color: 'var(--text-heading)',
      margin: '0 0 10px'
    }
  }, "Request a Quote"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      color: 'var(--text-body)',
      margin: '0 0 32px'
    }
  }, "Tell us about your dream trip and we'll get back to you within 24 hours."), sent && /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(Alert, {
    variant: "success"
  }, "Thanks! Your request has been sent \u2014 we'll be in touch on WhatsApp or email shortly.")), /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      borderRadius: 'var(--radius-lg)',
      border: '1px solid var(--border-warm)',
      padding: 32,
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'block',
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--text-heading)',
      marginBottom: 10,
      fontFamily: 'var(--font-body)'
    }
  }, "Which trail interests you?"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement(Radio, {
    name: "trail",
    checked: trail === 'bike',
    onChange: () => setTrail('bike'),
    label: "Group Bike Tour"
  }), /*#__PURE__*/React.createElement(Radio, {
    name: "trail",
    checked: trail === 'private',
    onChange: () => setTrail('private'),
    label: "Private Safari"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Full name",
    required: true,
    placeholder: "Jane Traveller"
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Email",
    type: "email",
    required: true,
    placeholder: "you@example.com"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(SelectField, {
    label: "Group size"
  }, /*#__PURE__*/React.createElement("option", null, "1\u20132 travellers"), /*#__PURE__*/React.createElement("option", null, "3\u20135 travellers"), /*#__PURE__*/React.createElement("option", null, "6+ travellers")), /*#__PURE__*/React.createElement(SelectField, {
    label: "Preferred month"
  }, /*#__PURE__*/React.createElement("option", null, "Flexible"), /*#__PURE__*/React.createElement("option", null, "August 2026"), /*#__PURE__*/React.createElement("option", null, "September 2026"), /*#__PURE__*/React.createElement("option", null, "October 2026"))), /*#__PURE__*/React.createElement(TextareaField, {
    label: "Tell us about your trip",
    rows: 4,
    placeholder: "Dates, interests, special occasions..."
  }), /*#__PURE__*/React.createElement(Checkbox, {
    checked: agree,
    onChange: setAgree,
    label: "I agree to be contacted about this enquiry via email or WhatsApp"
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    disabled: !agree,
    onClick: () => setSent(true)
  }, "Send Request"))));
}
window.QuoteRequestPage = QuoteRequestPage;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/QuoteRequestPage.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/TourDetailPage.jsx
try { (() => {
const {
  Button,
  StaffPill,
  ProgressBar
} = window.SafariAdventureRidersDesignSystem_473602;
const DEPARTURES = [{
  id: 1,
  start: 'Aug 12, 2026',
  end: 'Aug 20, 2026',
  seats: 4,
  max: 12,
  price: 2450,
  status: 'available'
}, {
  id: 2,
  start: 'Sep 3, 2026',
  end: 'Sep 11, 2026',
  seats: 2,
  max: 12,
  price: 2450,
  status: 'low'
}, {
  id: 3,
  start: 'Oct 1, 2026',
  end: 'Oct 9, 2026',
  seats: 0,
  max: 12,
  price: 2450,
  status: 'full'
}];
const STAFF = [{
  name: 'James Otieno',
  role: 'Lead Guide'
}, {
  name: 'Fatima Noor',
  role: 'Trip Coordinator'
}, {
  name: 'Peter Kamau',
  role: 'Driver'
}];
function TourDetailPage({
  lang,
  go,
  tour
}) {
  const isAr = lang === 'ar';
  const active = tour || window.TOURS[0];
  const accent = active.type === 'bike' ? '#B0492B' : '#C9A24B';
  const tripLabel = active.type === 'bike' ? isAr ? 'جولة دراجات' : 'Bike Tour' : isAr ? 'سفاري خاص' : 'Private Safari';
  const statusBadge = s => {
    const map = {
      available: {
        bg: 'var(--status-success-bg)',
        fg: 'var(--status-success-fg)',
        label: 'available'
      },
      low: {
        bg: 'var(--status-warn-bg)',
        fg: 'var(--status-warn-fg)',
        label: 'seats left'
      },
      full: {
        bg: 'var(--status-neutral-bg)',
        fg: 'var(--status-neutral-fg)',
        label: 'Fully Booked'
      }
    };
    return map[s];
  };
  return /*#__PURE__*/React.createElement("div", {
    dir: isAr ? 'rtl' : 'ltr'
  }, /*#__PURE__*/React.createElement("section", {
    style: {
      position: 'relative',
      minHeight: '78vh',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'flex-end',
      overflow: 'hidden',
      background: 'var(--bush)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      backgroundImage: `url(${active.img})`,
      backgroundSize: 'cover',
      backgroundPosition: 'center'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'var(--grad-hero)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 1,
      maxWidth: 'var(--container-md)',
      margin: '0 auto',
      width: '100%',
      padding: '0 24px 56px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      padding: '5px 16px',
      borderRadius: 4,
      background: accent,
      color: '#fff',
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      fontFamily: 'var(--font-body)',
      marginBottom: 20
    }
  }, tripLabel), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'clamp(2rem,5vw,3.6rem)',
      fontWeight: 700,
      color: '#fff',
      lineHeight: 1.08,
      margin: '0 0 14px',
      maxWidth: 700
    }
  }, active.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 17,
      color: 'rgba(255,255,255,0.78)',
      maxWidth: 560,
      lineHeight: 1.6,
      margin: '0 0 24px',
      fontFamily: 'var(--font-body)'
    }
  }, active.desc), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 8,
      marginBottom: 32
    }
  }, [`${active.days} days`, active.countries, active.type === 'bike' ? 'max 10' : 'max 6'].map(c => /*#__PURE__*/React.createElement("span", {
    key: c,
    style: {
      padding: '4px 14px',
      borderRadius: 999,
      background: 'rgba(255,255,255,0.12)',
      border: '1px solid rgba(255,255,255,0.22)',
      fontSize: 13,
      fontWeight: 600,
      color: '#fff'
    }
  }, c))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      alignItems: 'center',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'rgba(255,255,255,0.6)',
      display: 'block'
    }
  }, "From"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'clamp(1.8rem,4vw,2.6rem)',
      fontWeight: 700,
      color: '#fff'
    }
  }, "$2,450", /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '0.45em',
      color: 'rgba(255,255,255,0.6)',
      fontWeight: 400,
      marginInlineStart: 6
    }
  }, "/ person"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("a", {
    style: {
      padding: '14px 28px',
      borderRadius: 8,
      background: accent,
      color: '#fff',
      fontWeight: 700,
      fontSize: 15,
      cursor: 'pointer'
    }
  }, "Book Now"), /*#__PURE__*/React.createElement("a", {
    onClick: () => go('quote'),
    style: {
      padding: '14px 28px',
      borderRadius: 8,
      background: 'rgba(255,255,255,0.12)',
      color: '#fff',
      border: '1.5px solid rgba(255,255,255,0.4)',
      fontWeight: 700,
      fontSize: 15,
      cursor: 'pointer'
    }
  }, "Request Quote"))))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '64px 24px',
      background: '#fff'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-md)',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 22,
      fontWeight: 700,
      color: 'var(--text-heading)',
      margin: '0 0 24px'
    }
  }, "Upcoming Departures"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, DEPARTURES.map(d => {
    const s = statusBadge(d.status);
    const pct = Math.round((d.max - d.seats) / d.max * 100);
    return /*#__PURE__*/React.createElement("div", {
      key: d.id,
      style: {
        background: d.status === 'full' ? '#f9f9f7' : '#fff',
        borderRadius: 12,
        border: '1px solid var(--border-warm)',
        padding: '20px 24px',
        display: 'flex',
        flexWrap: 'wrap',
        alignItems: 'center',
        gap: 20,
        opacity: d.status === 'full' ? 0.7 : 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: '1 1 200px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-display)',
        fontSize: 16,
        fontWeight: 600,
        color: 'var(--text-heading)'
      }
    }, d.start, " ", /*#__PURE__*/React.createElement("span", {
      style: {
        color: 'var(--text-muted)',
        margin: '0 8px'
      }
    }, "\u2192"), " ", d.end), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: 'var(--text-muted)'
      }
    }, active.days, " days")), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: '1 1 160px'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        padding: '3px 10px',
        borderRadius: 999,
        background: s.bg,
        color: s.fg,
        fontSize: 12,
        fontWeight: 600
      }
    }, d.status === 'low' ? `${d.seats} ${s.label}` : d.status === 'available' ? `${d.seats} ${s.label}` : s.label), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 8,
        width: 160
      }
    }, /*#__PURE__*/React.createElement(ProgressBar, {
      percent: pct
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: '0 0 auto',
        display: 'flex',
        alignItems: 'center',
        gap: 16
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: 'var(--text-muted)'
      }
    }, "per person"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-display)',
        fontSize: 20,
        fontWeight: 700,
        color: 'var(--text-heading)'
      }
    }, "$", d.price.toLocaleString())), /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "sm"
    }, "Details"), d.status !== 'full' && /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "sm"
    }, "Book")));
  })))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '0 24px 72px',
      background: '#fff'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-md)',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 18,
      fontWeight: 700,
      color: 'var(--text-heading)',
      marginBottom: 18
    }
  }, "Meet Your Team"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 14
    }
  }, STAFF.map(m => /*#__PURE__*/React.createElement(StaffPill, {
    key: m.name,
    name: m.name,
    role: m.role
  }))))));
}
window.TourDetailPage = TourDetailPage;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/TourDetailPage.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ToursPage.jsx
try { (() => {
const {
  Button
} = window.SafariAdventureRidersDesignSystem_473602;
const TOURS = [{
  id: 1,
  type: 'bike',
  title: 'Nairobi to Coast Ride',
  img: 'https://images.unsplash.com/photo-1549366021-9f761d450615?auto=format&fit=crop&w=700&q=70',
  days: 9,
  countries: 'Kenya',
  desc: 'A fully-supported group motorcycle tour from the capital to the Indian Ocean, through the Rift Valley and Tsavo.'
}, {
  id: 2,
  type: 'private',
  title: 'Masai Mara Private Safari',
  img: 'https://images.unsplash.com/photo-1534177616072-ef7dc120449d?auto=format&fit=crop&w=700&q=70',
  days: 6,
  countries: 'Kenya',
  desc: 'Exclusive camps and a private guide through the heart of the Mara, timed for the Great Migration.'
}, {
  id: 3,
  type: 'bike',
  title: 'Mount Kenya Highlands Loop',
  img: 'https://images.unsplash.com/photo-1516426122078-c23e76319801?auto=format&fit=crop&w=700&q=70',
  days: 7,
  countries: 'Kenya',
  desc: 'Forest trails and highland switchbacks around Africa\u2019s second-highest peak.'
}, {
  id: 4,
  type: 'private',
  title: 'Serengeti & Ngorongoro',
  img: 'https://images.unsplash.com/photo-1547970810-dc1eac37d174?auto=format&fit=crop&w=700&q=70',
  days: 8,
  countries: 'Tanzania',
  desc: 'Luxury tented camps across two of East Africa\u2019s most iconic conservation areas.'
}, {
  id: 5,
  type: 'bike',
  title: 'Great Rift Valley Explorer',
  img: 'https://images.unsplash.com/photo-1535941339077-2dd1c7963098?auto=format&fit=crop&w=700&q=70',
  days: 5,
  countries: 'Kenya',
  desc: 'Volcanic lakes, escarpments and flamingo colonies — an intermediate 5-day ride.'
}, {
  id: 6,
  type: 'private',
  title: 'Amboseli & Kilimanjaro Views',
  img: 'https://images.unsplash.com/photo-1504173010664-32509aeebb62?auto=format&fit=crop&w=700&q=70',
  days: 4,
  countries: 'Kenya',
  desc: 'Elephant herds against the backdrop of Kilimanjaro, from a private tented camp.'
}];
function ToursPage({
  lang,
  go
}) {
  const isAr = lang === 'ar';
  const t = isAr ? {
    title: 'جولات السفاري لدينا',
    subtitle: 'استكشف مجموعتنا المختارة من تجارب السفاري التي لا تُنسى في شرق أفريقيا.',
    days: 'أيام',
    requestQuote: 'طلب عرض سعر',
    ctaTitle: 'لم تجد الجولة المثالية؟',
    ctaText: 'أخبرنا بتفضيلاتك وسننشئ رحلة سفاري مخصصة لك.',
    ctaButton: 'أنشئ جولة مخصصة'
  } : {
    title: 'Our Safari Tours',
    subtitle: "Explore our curated collection of unforgettable East African safari experiences.",
    days: 'days',
    requestQuote: 'View Tour',
    ctaTitle: "Can't Find the Perfect Tour?",
    ctaText: "Let us know your preferences and we'll create a custom safari just for you.",
    ctaButton: 'Create a Custom Tour'
  };
  return /*#__PURE__*/React.createElement("div", {
    dir: isAr ? 'rtl' : 'ltr'
  }, /*#__PURE__*/React.createElement("section", {
    style: {
      color: '#fff',
      padding: '88px 24px',
      textAlign: 'center',
      backgroundImage: `linear-gradient(rgba(20,25,15,0.72), rgba(20,25,15,0.8)), url(https://images.unsplash.com/photo-1516426122078-c23e76319801?auto=format&fit=crop&w=1600&q=60)`,
      backgroundSize: 'cover',
      backgroundPosition: 'center'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--fs-display)',
      fontWeight: 700,
      margin: '0 0 16px'
    }
  }, t.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 17,
      color: 'rgba(255,255,255,0.8)',
      maxWidth: 640,
      margin: '0 auto'
    }
  }, t.subtitle)), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '64px 24px',
      background: '#fff'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-md)',
      margin: '0 auto',
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(280px,1fr))',
      gap: 28
    }
  }, TOURS.map(tour => {
    const accent = tour.type === 'bike' ? 'var(--murram)' : 'var(--gold)';
    return /*#__PURE__*/React.createElement("div", {
      key: tour.id,
      style: {
        background: '#fff',
        borderRadius: 'var(--radius-lg)',
        border: '1px solid var(--border-warm)',
        overflow: 'hidden',
        cursor: 'pointer'
      },
      onClick: () => go('tour-detail', tour)
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        height: 180,
        backgroundImage: `url(${tour.img})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        position: 'relative'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        top: 12,
        insetInlineStart: 12,
        background: accent,
        color: '#fff',
        fontSize: 11,
        fontWeight: 700,
        letterSpacing: '0.06em',
        textTransform: 'uppercase',
        padding: '4px 10px',
        borderRadius: 'var(--radius-pill)'
      }
    }, tour.type === 'bike' ? 'Bike Tour' : 'Private Safari')), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 22
      }
    }, /*#__PURE__*/React.createElement("h3", {
      style: {
        fontFamily: 'var(--font-display)',
        fontSize: 18,
        fontWeight: 700,
        color: 'var(--text-heading)',
        margin: '0 0 6px'
      }
    }, tour.title), /*#__PURE__*/React.createElement("p", {
      style: {
        fontSize: 13,
        color: 'var(--text-muted)',
        margin: '0 0 10px',
        fontFamily: 'var(--font-body)'
      }
    }, tour.countries, " \xB7 ", tour.days, " ", t.days), /*#__PURE__*/React.createElement("p", {
      style: {
        fontSize: 14,
        color: 'var(--text-body)',
        lineHeight: 1.6,
        margin: '0 0 18px',
        fontFamily: 'var(--font-body)'
      }
    }, tour.desc), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "sm"
    }, t.requestQuote)));
  }))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '64px 24px',
      background: 'var(--admin-bg)',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 24,
      fontWeight: 700,
      color: 'var(--text-heading)',
      margin: '0 0 12px'
    }
  }, t.ctaTitle), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      color: 'var(--text-body)',
      margin: '0 0 24px'
    }
  }, t.ctaText), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    onClick: () => go('quote')
  }, t.ctaButton)));
}
window.ToursPage = ToursPage;
window.TOURS = TOURS;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ToursPage.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.StaffPill = __ds_scope.StaffPill;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.FeatureCard = __ds_scope.FeatureCard;

__ds_ns.ProgressBar = __ds_scope.ProgressBar;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Alert = __ds_scope.Alert;

__ds_ns.StatusBadge = __ds_scope.StatusBadge;

__ds_ns.TrailBadge = __ds_scope.TrailBadge;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Field = __ds_scope.Field;

__ds_ns.TextareaField = __ds_scope.TextareaField;

__ds_ns.SelectField = __ds_scope.SelectField;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Toggle = __ds_scope.Toggle;

__ds_ns.LanguageToggle = __ds_scope.LanguageToggle;

__ds_ns.NavLink = __ds_scope.NavLink;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Dialog = __ds_scope.Dialog;

})();
